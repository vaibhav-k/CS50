<?php
    // configuration
    require("../includes/config.php"); 
    
    // fill the array of user shares
    $rows = CS50::query("SELECT * FROM history WHERE id = ?", $_SESSION["id"]);
    render("history_view.php", ["title" => "History", "symbols" => $rows]);
?>