<?php

    // configuration
    require("../includes/config.php");
    
    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("stock_submit.php", ["title" => "Stock Submit"]);
    }
    
    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        $_POST["symbol"] = strtoupper($_POST["symbol"]);
        
        // validate submission
        if (empty($_POST["symbol"]))
        {
            apologize("You must provide a symbol.");
        }
        
        // query database for stock
        $stock = lookup($_POST["symbol"]);
        
        // verify submission
        if ($stock == false)
        {
            apologize("Stock lookup failed.");
        }
        // display stoc information
        else
        {
            $stock["price"] = number_format($stock["price"], 2);
            
            $_SESSION["symbol"] = $stock["symbol"];
            $_SESSION["name"] = $stock["name"];
            $_SESSION["price"] = $stock["price"];
            
            render("stock_view.php", ["title" => "Stock View"]);
        }
    }
    
?>