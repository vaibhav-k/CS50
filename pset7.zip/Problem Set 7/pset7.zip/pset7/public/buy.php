<?php

    // configuration
    require("../includes/config.php");
    
    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("buy_stock.php", ["title" => "Buy Stock"]);
    }
    
    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        $_POST["symbol"] = strtoupper($_POST["symbol"]);
        
        // validate submission
        if (empty($_POST["symbol"]))
        {
            apologize("You must provide a symbol.");
        }
        else if (empty($_POST["shares"]))
        {
            apologize("You must provide number of stocks you wish to buy.");
        }
        else if (preg_match("/^\d+$/", $_POST["shares"]) == false)
        {
            apologize("Shares must be non-negative integers.");
        }
        
        $rows = CS50::query("SELECT * from users where id = ?", $_SESSION["id"]);
        
        $cash_available = $rows[0]["cash"];
        
        // query database for stock
        $stock = lookup($_POST["symbol"]);
        
        // verify submission
        if ($stock == false)
        {
            apologize("Stock not available.");
        }
        
        $amount = $_POST["shares"] * $stock["price"];
        
        if ($amount >  $cash_available)
        {
            apologize("You don't have enough money to buy this stock.");
        }

        $buy = CS50::query("INSERT INTO portfolio (user_id, symbol, shares) VALUES(?, ?, ?) ON DUPLICATE KEY UPDATE shares = shares + VALUES(shares)", $_SESSION["id"], $_POST["symbol"], $_POST["shares"]);
        if ($buy === false)
        {
            apologize("Error while updating stocks.");
        }
        
        $deduct = CS50::query("UPDATE users SET cash = cash - ? WHERE id = ?", $amount, $_SESSION["id"]);
        if ($deduct === false)
        {
            apologize("Error while deducting money.");
        }
        
        // Log the history
        $history = CS50::query("INSERT INTO history(id, symbol, action, shares, price, time) VALUES (?, ?, ?, ?, ?, Now())", $_SESSION["id"], $stock["symbol"], "BUY", $_POST["shares"], $stock["price"]);
        if ($history === false)
        {
            apologize("history logging error");
        }
        
        redirect("/");
    }
    
?>