<?php

    // configuration
    require("../includes/config.php");
    
    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("sell_stock.php", ["title" => "Sell Stock"]);
    }
    
    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        $_POST["symbol"] = strtoupper($_POST["symbol"]);
        
        // validate submission
        if (empty($_POST["symbol"]))
        {
            apologize("You must provide a symbol.");
        }
        
        $rows = CS50::query("SELECT symbol, shares FROM portfolio WHERE user_id=? AND symbol= ?", $_SESSION["id"], $_POST["symbol"]);
        
        if ($rows == false)
        {
            apologize("Please choose a stock which you own.");
        }
        
        // query database for stock
        $stock = lookup($_POST["symbol"]);
        
        // verify submission
        if ($stock == false)
        {
            apologize("Stock not available.");
        }
        
        $amount = $rows[0]["shares"] * $stock["price"];
        
        $sell =CS50::query("DELETE FROM portfolio WHERE user_id = ? AND symbol = ?", $_SESSION["id"], $_POST["symbol"]);
        if ($sell === false)
        {
            apologize("Error while updating stocks.");
        }
        
        $refund =CS50::query("UPDATE users SET cash = cash + ? WHERE id = ?", $amount, $_SESSION["id"]);
        if ($refund === false)
        {
            apologize("Error while refunding money.");
        }
        
        // Log the history
        $history = CS50::query("INSERT INTO history(id, symbol, action, shares, price, time) VALUES (?, ?, ?, ?, ?, Now())", $_SESSION["id"], $stock["symbol"], "SELL", $_POST["shares"], $stock["price"]);
        if ($history === false)
        {
            apologize("history logging error");
        }

        redirect("/");
    }
    
?>