<?php

    // configuration
    require("../includes/config.php");

    // if user reached page via GET (as by clicking a link or via redirect)
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("add_cash.php", ["title" => "Add Cash"]);
    }

    // else if user reached page via POST (as by submitting a form via POST)
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        // validate submission
        if (empty($_POST["cash"]))
        {
            apologize("You must enter an amount in dollars.");
        }
        else if ($_POST["cash"] > 10000)
        {
            apologize("You must enter an amount less than 10000 dollars.");
        }
        
        $add =CS50::query("UPDATE users SET cash = cash + ? WHERE id = ?", $_POST["cash"], $_SESSION["id"]);
        if ($add === false)
        {
            apologize("Error while adding money.");
        }
        
        // Log the history
        $history = CS50::query("INSERT INTO history(id, action, price, time) VALUES (?, ?, ?, Now())", $_SESSION["id"], "ADD", $_POST["cash"]);
        if ($history === false)
        {
            apologize("history logging error");
        }

        redirect("/");
    }
    
?>