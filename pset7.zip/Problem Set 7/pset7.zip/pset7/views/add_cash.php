You must enter an amount less than <b>$10,000</b>.<br><br>

<form action="add.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="cash" placeholder="Enter amount" type="text"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit">
                <span aria-hidden="true" class="glyphicon glyphicon-log-in"></span>
                Add
            </button>
        </div>
    </fieldset>
</form>