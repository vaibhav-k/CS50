<div class="container">
  <table class="table table-striped">
    <thead align = center>
      <tr>
        <th>SYMBOL</th>
        <th>ACTION</th>
        <th>SHARES</th>
        <th>PRICE PER SHARE(WHEN BOUGHT)</th>
        <th>TIME</th>
      </tr>
    </thead>
    <tbody>
<?php foreach($symbols as $symbol): ?>
        <tr>
            <td><?= $symbol['symbol'] ?></td>
            <td><?= $symbol['action'] ?></td>
            <td><?= $symbol['shares'] ?></td>
            <td><?= $symbol['price'] ?></td>
            <td><?= $symbol['time'] ?></td>
            <br><br>
        </tr>
<?php endforeach ?>
</tbody>
  </table>
</div>