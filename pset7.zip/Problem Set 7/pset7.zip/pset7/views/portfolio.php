Dear customer, your current balance is <b>$<?= number_format($cash, 2)?></b><br>
<div class="container">
  <table class="table table-striped">
    <thead align = center>
      <tr>
        <th>SYMBOL</th>
        <th>SHARES</th>
        <th>PRICE</th>
      </tr>
    </thead>
    <tbody>
<?php foreach ($positions as $position): ?>

    <tr>
        <td><?= $position["symbol"] ?></td>
        <td><?= $position["shares"] ?></td>
        <td><?= $position["price"] ?></td>
        <br><br>
    </tr>

<?php endforeach ?>
</tbody>
  </table>
</div>