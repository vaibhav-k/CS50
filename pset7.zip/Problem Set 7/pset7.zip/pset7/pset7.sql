-- MySQL dump 10.13  Distrib 5.5.49, for debian-linux-gnu (x86_64)
--
-- Host: 0.0.0.0    Database: pset7
-- ------------------------------------------------------
-- Server version	5.5.49-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history` (
  `id` int(10) unsigned NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `action` varchar(4) NOT NULL,
  `shares` int(10) unsigned NOT NULL,
  `price` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
INSERT INTO `history` VALUES (12,'AAPL','BUY',1,100,'2016-07-21 16:43:31'),(13,'AAPL','BUY',50,4984,'2016-07-21 16:48:04'),(13,'MSFT','BUY',1,56,'2016-07-21 16:48:13'),(13,'TSLA','BUY',10,2215,'2016-07-21 16:48:22'),(13,'INFY','BUY',34,565,'2016-07-21 16:49:29'),(13,'MSFT','SELL',0,56,'2016-07-21 16:49:40'),(17,'AAPL','BUY',23,2290,'2016-07-21 17:15:20'),(17,'','ADD',0,7878,'2016-07-21 17:16:23'),(17,'','ADD',0,345,'2016-07-21 17:16:34'),(17,'MSFT','BUY',32,1793,'2016-07-21 18:19:50'),(17,'','ADD',0,243,'2016-07-21 18:19:55'),(18,'TSLA','BUY',10,2205,'2016-07-22 04:05:35'),(18,'','ADD',0,1000,'2016-07-22 04:06:09'),(18,'','ADD',0,10000,'2016-07-22 04:06:30'),(18,'','ADD',0,10000,'2016-07-22 04:06:50'),(19,'AAPL','BUY',43,4275,'2016-07-22 04:17:37'),(19,'','ADD',0,10000,'2016-07-22 04:17:51'),(20,'AAPL','BUY',10,994,'2016-07-22 04:29:44'),(20,'MSFT','BUY',8,446,'2016-07-22 04:30:17'),(21,'AAPL','BUY',10,994,'2016-07-22 04:32:09'),(21,'TSLA','BUY',23,5072,'2016-07-22 04:32:22'),(21,'MSFT','BUY',4,223,'2016-07-22 04:32:51'),(21,'GOOG','BUY',5,3693,'2016-07-22 04:33:08'),(21,'','ADD',0,10000,'2016-07-22 04:33:20'),(21,'TSLA','SELL',0,5072,'2016-07-22 04:33:32'),(21,'AAPL','BUY',2,99,'2016-07-22 04:35:43');
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portfolio`
--

DROP TABLE IF EXISTS `portfolio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portfolio` (
  `user_id` int(10) unsigned NOT NULL,
  `symbol` varchar(255) NOT NULL,
  `shares` int(11) unsigned NOT NULL,
  UNIQUE KEY `user_id` (`user_id`,`symbol`),
  UNIQUE KEY `user_id_2` (`user_id`,`symbol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portfolio`
--

LOCK TABLES `portfolio` WRITE;
/*!40000 ALTER TABLE `portfolio` DISABLE KEYS */;
INSERT INTO `portfolio` VALUES (1,'AAPL',108),(2,'MSFT',34),(3,'TSLA',125),(4,'GOOG',30),(5,'BMW.DE',244),(6,'SNE',55),(7,'RCOM.BO',156),(8,'WIPRO.BO',89),(9,'ITC.BO',223),(10,'INFY.BO',178),(11,'AAPL',10),(11,'MSFT',45),(12,'AAPL',58),(13,'AAPL',50),(13,'INFY',34),(13,'TSLA',10),(17,'AAPL',23),(17,'MSFT',32),(18,'TSLA',10),(19,'AAPL',43),(20,'AAPL',10),(20,'MSFT',8),(21,'AAPL',12),(21,'GOOG',5),(21,'MSFT',4);
/*!40000 ALTER TABLE `portfolio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `cash` decimal(65,4) unsigned NOT NULL DEFAULT '0.0000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'andi','$2y$10$c.e4DK7pVyLT.stmHxgAleWq4yViMmkwKz3x8XCo4b/u3r8g5OTnS',10000.0000),(2,'caesar','$2y$10$0p2dlmu6HnhzEMf9UaUIfuaQP7tFVDMxgFcVs0irhGqhOxt6hJFaa',10000.0000),(3,'eli','$2y$10$COO6EnTVrCPCEddZyWeEJeH9qPCwPkCS0jJpusNiru.XpRN6Jf7HW',10000.0000),(4,'hdan','$2y$10$o9a4ZoHqVkVHSno6j.k34.wC.qzgeQTBHiwa3rpnLq7j2PlPJHo1G',10000.0000),(5,'jason','$2y$10$ci2zwcWLJmSSqyhCnHKUF.AjoysFMvlIb1w4zfmCS7/WaOrmBnLNe',10000.0000),(6,'john','$2y$10$dy.LVhWgoxIQHAgfCStWietGdJCPjnNrxKNRs5twGcMrQvAPPIxSy',10000.0000),(7,'levatich','$2y$10$fBfk7L/QFiplffZdo6etM.096pt4Oyz2imLSp5s8HUAykdLXaz6MK',10000.0000),(8,'rob','$2y$10$3pRWcBbGdAdzdDiVVybKSeFq6C50g80zyPRAxcsh2t5UnwAkG.I.2',10000.0000),(9,'skroob','$2y$10$395b7wODm.o2N7W5UZSXXuXwrC0OtFB17w4VjPnCIn/nvv9e4XUQK',10000.0000),(10,'zamyla','$2y$10$UOaRF0LGOaeHG4oaEkfO4O7vfI34B1W23WqHr9zCpXL68hfQsS3/e',10000.0000),(17,'Vaibhav','$2y$10$mDJBtj67QTAfkxiOOo4vJu1oCpzE1MQzVD/KKKmjWTTEW8ZNDMyru',38304.2900),(18,'test2','$2y$10$IlyaMJwg4qsRfK2U9qTZ.upmFsI9hDTPK/G5f0rxuYt/T4eLhPwZW',33205.0000),(19,'Vaibhav Kulshrestha','$2y$10$3uzdwDTLzmHG3Dw7HThi3.lStQ681Xl23O0D5yIy5HP28xxVGfpMC',24275.4900),(20,'rashmi','$2y$10$FtCxPIChenuxtGXxlOZGYeKLcy4PHC6E2AiAApXznRl/E/Z.t5CqK',11440.7000),(21,'Rashmi2','$2y$10$nqTkpY9EI4K2gvlIOU6y7..MueOqkSXnDtdSVc6Vbz2TEFU8ksg0O',14890.4900);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-22  4:39:41
