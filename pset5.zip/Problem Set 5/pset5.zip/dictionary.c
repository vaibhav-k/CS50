/**
 * dictionary.c
 *
 * Computer Science 50
 * Problem Set 5
 *
 * Implements a dictionary's functionality.
 */

#include <stdbool.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dictionary.h"

// Create a struct for trie
typedef struct node
{
    bool is_word;
    struct node* children[27];
}node;

// Declare head node, tracker pointer and word count tracker
node* root =  NULL;
node* cursor = NULL;
int word_count = 0;

// Hashes input
int hash(int c)
{
    if (c >= 'A' && c <= 'Z')
    {
        return (c - 'A');
    }
    else if (c >= 'a' && c <= 'z')
    {
        return (c - 'a');
    }
    else if (c == '\'')
    {
        return 26;
    }
    else
    {
        return false;
    }
};

// Frees the specified node
void freenode(node* ptr)
{
    // Iterate through children array
    for (int i = 0; i < 27; i++)
    {
        if (ptr -> children[i] !=NULL)
        {
            freenode(ptr -> children[i]);
        }
    }
    free(ptr);
    ptr = NULL;
    return;
}

/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char* word)
{
    // Set pointer at head of trie
    cursor = root;
    
    // Compare letter by letter of word
    for (int i = 0, n = strlen(word); i < n; i++)
    {
        if (cursor -> children[hash(word[i])] == NULL)
        {
            return false;
            break;
        }
        else
        {
            cursor = cursor -> children[hash(word[i])];
        }
    }
    if (cursor -> is_word == true)
    {
        return true;
    }
    else
    {
        return false;
    }
}

/**
 * Loads dictionary into memory.  Returns true if successful else false.
 */
bool load(const char* dictionary)
{
    // Make root of trie
    root = calloc(1, sizeof(node));

    // Open dictionary
    FILE* fp = fopen(dictionary, "r");
    if (fp == NULL)
    {
        printf("Could not open %s.\n", dictionary);
        return false;
    }
    else
    {
        // Iterate through dictionary, word by word
        for (int c = fgetc(fp); c != EOF; c = fgetc(fp))
        {
            // set tracker back to root for new word
            cursor = root;
            
            // Iterate through word, letter by letter
            while (c != '\n')
            {
                // Move through the trie
                if (cursor -> children[hash(c)] == NULL)
                {
                    cursor -> children[hash(c)] = calloc(1, sizeof(node));
                    cursor = cursor -> children[hash(c)];
                }
                else
                {
                    cursor = cursor -> children[hash(c)];
                }
                
                c = fgetc(fp);
            }
            
            // Mark ending of word
            cursor -> is_word = true;
            word_count++;
        }
        
        // Free memory by closing dictionary
        fclose(fp);
        return true;
    }
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    if (root != NULL)
    {
        return word_count;
    }
    else
    {
        return 0;
    }
}

/**
 * Unloads dictionary from memory.  Returns true if successful else false.
 */
bool unload(void)
{
    freenode(root);
    return true;
}