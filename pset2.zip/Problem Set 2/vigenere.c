#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, string argv[])
{
    if (argc!=2)
    {
        printf("Please enter only one argument!\n");
        return 1;
    }
    else 
    {
        string key = argv[1];
        
        int keylen = strlen(key);
        
        for (int g = 0 ; g < keylen ; g++ )
        {
            if ( ( key[g]>=65 && key[g]<=90 ) || ( key[g]>=97 && key[g]<=122 ) )
            {
                continue;
            }
            else
            {
                printf("Keyword should only contain alphabets!");
                return 1;
            }
        }
        
        string text = GetString();
        
        if (text != NULL)
        {
            char keyrep[1000] = {0};
            
            int textlen = strlen(text);
            
            for (int i = 0 , j = 0 ; i < textlen ; i++)
            {

                if ( ( text[i]>=65 && text[i]<=90 ) || ( text[i]>=97 && text[i]<=122 ) )
                {
                    keyrep[i] = key[j];
                    j++;
                    
                    if (j == keylen)
                    {
                        j=0;
                    }
                }
                else
                {
                    keyrep[i] = text[i];
                }
            }
            
            for (int i = 0, n = strlen(text); i < n; i++)
            {
                if ( ( text[i]>=65 && text[i]<=90 ) || ( text[i]>=97 && text[i]<=122 ) )
                {
                    int offset = 0;
                    
                    if ( keyrep[i]>=65 && keyrep[i]<=90 )                   
                    {
                        offset = keyrep[i] - 65;
                    }
                    else
                    {
                        offset = keyrep[i] - 97;
                    }
                    
                    int a = text[i] + offset;
                
                    if( ( ( a>=65 && a<=90 ) && ( text[i]>=65 && text[i]<=90 ) ) || ( ( a>=97 && a<=122 ) && ( text[i]>=97 && text[i]<=122 ) ) )
                    {
                        printf("%c", text[i] + offset);        
                    }
                    else
                    {
                        printf("%c", text[i] + offset - 26);
                    }
                }       
                else
                {
                    printf("%c", text[i]);
                }
            }
            
            printf("\n");   

        }
        else
        {
            return 1;
        }
    }
}