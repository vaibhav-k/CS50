#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, string argv[])
{
    if (argc!=2)
    {
        printf("Please enter only one argument!\n");
        return 1;
    }
    else 
    {
        string text = GetString();
        
        if (text != NULL)
        {
            int k = atoi(argv[1]);

            int key = k%26;
        
            for (int i = 0, n = strlen(text); i < n; i++)
            {
                if ( ( text[i]>=65 && text[i]<=90 ) || ( text[i]>=97 && text[i]<=122 ) )
                {
                    int a = text[i] + key;
                
                    if( ( ( a>=65 && a<=90 ) && ( text[i]>=65 && text[i]<=90 ) ) || ( ( a>=97 && a<=122 ) && ( text[i]>=97 && text[i]<=122 ) ) )  
                    {
                        printf("%c", text[i]+key);        
                    }
                    else
                    {
                        printf("%c", text[i]+key-26);
                    }
                }       
                else
                {
                    printf("%c", text[i]);
                }
                    
            }
            
            printf("\n");
        }
        else
        {
            return 1;
        }
    }
}