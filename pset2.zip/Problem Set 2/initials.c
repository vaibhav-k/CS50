#include <stdio.h>
#include <cs50.h>
#include <string.h>

int main()
{
    string name=GetString();
    int namelen=strlen(name);
    int i=0,j=1;
    char ininame[100]={0};
    
    if (name[0]<91 && name[0]>65)
    {
        ininame[0]=name[0];
    }
    else 
    {
        ininame[0]=name[0]-32;
    }
    
    for (i=0,j=1;i<namelen;i++)
    {
        if (name[i]==' ' && name[i+1]<91 && name[i+1]>65)
        {
            ininame[j++]=name[i+1];
        }
        else if (name[i]==' ')
        {
            ininame[j++]=name[i+1]-32;
        }
    }
    
    for (i=0;i<j;i++)
    {
        printf("%c",ininame[i]);
    }
    
    printf("\n");
}