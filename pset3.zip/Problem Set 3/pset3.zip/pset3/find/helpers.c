/**
 * helpers.c
 *
 * Computer Science 50
 * Problem Set 3
 *
 * Helper functions for Problem Set 3.
 */
       
#include <cs50.h>

#include "helpers.h"

/**
 * Returns true if value is in array of n values, else false.
 */
 
bool binsearch(int value, int values[], int low, int high);
 
bool search(int value, int values[], int n)
{
    // TODO: implement a searching algorithm
    int low = 0;
    int high = n - 1;
    
    if (high >= low)
    {
        int mid = ( low + high )/2;
    
        if ( value == values[mid] )
        {
            return true;
        }
        else if ( value > values[mid] )
        {
            return binsearch( value,  values, mid + 1, n - 1);
        }
        else
        {
            return binsearch( value,  values, 0, mid - 1);
        }
    }
    else
    {
        return false;
    }
}

/**
 * Sorts array of n values.
 */
void sort(int values[], int n)
{
    // TODO: implement an O(n^2) sorting algorithm
    for ( int i = 0 ; i < (n - 1) ; i++ )
    {
        int min = i;
        int temp = 0;
        
        for ( int j = i + 1 ; j < n ; j++ )
        {
            if ( values[min] > values[j] )
            {
                min = j;
            }
        }
        
        if (min != i)
        {
            temp = values[min];
            values[min] = values[i];
            values[i] = temp;
        }
    }
    
    return;
}

bool binsearch(int value, int values[], int low, int high)
{
    if (high >= low)
    {
        int mid = (low + high)/2;
    
        if ( value == values[mid] )
        {
            return true;
        }
        else if ( value > values[mid] )
        {
            return binsearch( value, values, mid + 1, high );
        }
        else
        {
            return binsearch( value,  values, 0, mid - 1);
        }
    }
    else
    {
        return false;
    }
}