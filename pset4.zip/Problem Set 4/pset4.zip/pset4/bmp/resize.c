/**
 * resize.c
 *
 * Computer Science 50
 * Problem Set 4
 *
 * Resizes a BMP by specified factor.
 */
       
#include <stdio.h>
#include <stdlib.h>

#include "bmp.h"

int main(int argc, char* argv[])
{
    // ensure proper usage
    if (argc != 4)
    {
        printf("Usage: ./resize n infile outfile\n");
        return 1;
    }

    // remember filenames
    char* small = argv[2];
    char* large = argv[3];
    
    // get factor for resizing
    int n = atoi(argv[1]);
    
    if ( n < 1 || n > 100 )
    {
        printf("The factor should be a positive integer less than or equal to 100.\n");
        return 5;
    }

    // open input file 
    FILE* inptr = fopen(small, "r");
    if (inptr == NULL)
    {
        printf("Could not open %s.\n", small);
        return 2;
    }

    // open output file
    FILE* outptr = fopen(large, "w");
    if (outptr == NULL)
    {
        fclose(inptr);
        fprintf(stderr, "Could not create %s.\n", large);
        return 3;
    }

    // read small's BITMAPFILEHEADER
    BITMAPFILEHEADER bfsmall, bflarge;
    fread(&bfsmall, sizeof(BITMAPFILEHEADER), 1, inptr);

    // read small's BITMAPINFOHEADER
    BITMAPINFOHEADER bismall, bilarge;
    fread(&bismall, sizeof(BITMAPINFOHEADER), 1, inptr);

    // ensure small is (likely) a 24-bit uncompressed BMP 4.0
    if (bfsmall.bfType != 0x4d42 || bfsmall.bfOffBits != 54 || bismall.biSize != 40 || 
        bismall.biBitCount != 24 || bismall.biCompression != 0)
    {
        fclose(outptr);
        fclose(inptr);
        fprintf(stderr, "Unsupported file format.\n");
        return 4;
    }
    
    // change BITMAPINFOHEADER of large
    bilarge = bismall;
    bilarge.biWidth = bismall.biWidth*n;
    bilarge.biHeight = bismall.biHeight*n;
    
    // determine padding for scanlines
    int paddingsmall =  (4 - (bismall.biWidth * sizeof(RGBTRIPLE)) % 4) % 4;
    int paddinglarge =  (4 - (bilarge.biWidth * sizeof(RGBTRIPLE)) % 4) % 4;
    
    bilarge.biSizeImage = abs(bilarge.biHeight) * ((sizeof(RGBTRIPLE) * bilarge.biWidth) + paddinglarge);
    
    // change BITMAPFILEHEADER of large
    bflarge = bfsmall;
    bflarge.bfSize = 54 + bilarge.biSizeImage;

    // write large's BITMAPFILEHEADER
    fwrite(&bflarge, sizeof(BITMAPFILEHEADER), 1, outptr);

    // write large's BITMAPINFOHEADER
    fwrite(&bilarge, sizeof(BITMAPINFOHEADER), 1, outptr);

    // iterate over small's scanlines
    for (int i = 0, bismallHeight = abs(bismall.biHeight); i < bismallHeight; i++)
    {
        //copying rows n times to resize
        for (int k = 0; k < n; k++)
        {
            // iterate over pixels in scanline
            for (int j = 0; j < bismall.biWidth; j++)
            {
                // temporary storage
                RGBTRIPLE triple;

                // read RGB triple from small
                fread(&triple, sizeof(RGBTRIPLE), 1, inptr);

                // write RGB triple to large n times
                for (int l = 0; l < n; l++)
                {
                    fwrite(&triple, sizeof(RGBTRIPLE), 1, outptr);
                }
            }

            // skip over padding of small file, if any
            fseek(inptr, paddingsmall, SEEK_CUR);

            // then add padding to large
            for (int m = 0; m < paddinglarge; m++)
            {
                fputc(0x00, outptr);
            }
            
            // put cursor back at start of line in small file
            fseek(inptr, -((bismall.biWidth * sizeof(RGBTRIPLE)) + paddingsmall ), SEEK_CUR);
        }
        // put cursor at end of line in small file
        fseek(inptr, ((bismall.biWidth * sizeof(RGBTRIPLE)) + paddingsmall ), SEEK_CUR);
    }

    // close small
    fclose(inptr);

    // close large
    fclose(outptr);

    // that's all folks
    return 0;
}
