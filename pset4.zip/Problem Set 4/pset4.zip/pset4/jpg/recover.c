/**
 * recover.c
 *
 * Computer Science 50
 * Problem Set 4
 *
 * Recovers JPEGs from a forensic image.
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

typedef uint8_t  BYTE;

int main(int argc, char* argv[])
{
    // ensure proper usage
    if (argc != 1)
    {
        printf("Usage: ./recover\n");
        return 1;
    }
    
    // remember filenames
    char* infile = "card.raw";
    
    // open input file 
    FILE* inptr = fopen(infile, "r");
    if (inptr == NULL)
    {
        printf("Could not open %s.\n", infile);
        return 2;
    }
    
    // initialize some flags and counters
    int flag = 1;
    int isfirstjpg = 1;
    int isjpg = 0;
    int count = 0;
    FILE* img = NULL;
    char* title = malloc(8 * sizeof(char));
    BYTE bloc[512]={0};
    
    // read the card 512 bytes at a time
    do
    {
        // if fread gets 512 bytes (i.e. not EOF)
        if (fread(bloc,sizeof(BYTE),512,inptr) == 512)
        {
            // look for jpeg signature
            if (bloc[0] == 0xff && bloc[1] == 0xd8 && bloc[2] == 0xff)
            {
                switch (bloc[3])
                {
                    case 0xe0: 
                    case 0xe1: 
                    case 0xe2: 
                    case 0xe3: 
                    case 0xe4: 
                    case 0xe5: 
                    case 0xe6:
                    case 0xe7: 
                    case 0xe8: 
                    case 0xe9: 
                    case 0xea: 
                    case 0xeb: 
                    case 0xec: 
                    case 0xed: 
                    case 0xee: 
                    case 0xef:
                        isjpg = 1;
                        break;
                    default: isjpg = 0;
                }
                // if fread contains a jpg signature
                if (isjpg == 1)
                {
                    // if this is the first jpg encountered
                    if (isfirstjpg == 1)
                    {
                        // open a new file and write to  it
                        sprintf(title, "%03d.jpg", count++);
                        img = fopen(title, "w");
                    
                        fwrite(bloc,sizeof(BYTE),512,img);
                        isfirstjpg  = 0;
                        isjpg = 0;
                    }
                    // if this is not the first jpg encountered
                    else
                    {
                        // close earlier file, open a new file and write to it 
                        fclose(img);

                        sprintf(title, "%03d.jpg", count++);
                        img = fopen(title, "w");
                    
                        fwrite(bloc,sizeof(BYTE),512,img);
                        isjpg = 0;
                    }
                }
            }
            
            // if fread encounters empty block (i.e. not a part of any jpg)
            else if (img == NULL) // file pointer points to null and it is not a bloc with jpg signature
            {
                continue;
            }
            // if fread encounters a block which is part of a jpg, but does not contain a signature
            else
            {
                    // just write to file
                    fwrite(bloc,sizeof(BYTE),512,img);
            }
        }
         // if fread reaches end of file
        else
        {
            flag = 0;
        }
    }while (flag == 1);
    free(title);
}