#include <stdio.h>
#include <cs50.h>

int main()
{
    printf("minutes : ");
    int min=0;
    min=GetInt();
    printf("bottles : %i\n", min*12);
}