#include <stdio.h>
#include <cs50.h>

int main()
{
    int ht,i,j,k,totchar;
    
    do
    {
        printf("height : ");
        ht=GetInt();
    }while(ht>23 || ht<0);
    
    totchar=ht+1;
    
    for (i=0;i<ht;i++)
    {
        for (j=0;j<ht-i-1;j++)
        {
            printf(" ");
        }
        for (k=0;k<ht-j+1;k++)
        {
            printf("#");
        }
        printf("\n");
    }
}