#include <stdio.h>
#include <cs50.h>
#include <stdbool.h>
#include <math.h>
 
int main(void)
{
float changeDue = 0;
bool noRun = true;
 
printf ("Enter change due in dollar and cents: ");
 
while (noRun == true)
{
changeDue = GetFloat();
 
if (changeDue >= 0)
{
int asPennies = 0, numCoins = 0, quarter = 25, dime = 10,
nickel = 5, penny = 1;
 
/* convert to pennies by rounding to nearest integer value
due to floating point imprecision, and then type casting
the result to an int */
asPennies = (int) round(changeDue * 100);
 
// integer division
while (asPennies / quarter > 0)
{
numCoins += 1;
asPennies -= quarter;
}
// integer division
while (asPennies / dime > 0)
{
numCoins += 1;
asPennies -= dime;
}
// integer division
while (asPennies / nickel > 0)
{
numCoins += 1;
asPennies -= nickel;
}
// integer division
while (asPennies / penny > 0)
{
numCoins += 1;
asPennies -= penny;
}
 
printf ("%i\n", numCoins);
 
noRun = false;
}
else
{
printf ("Enter a non-negative number: ");
}
}
 
return 0;
}